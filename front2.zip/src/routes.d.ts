import { RouteObject } from 'react-router-dom';

declare module './routes' {
    export const router: RouteObject;
}
