import HomeIcon from "@mui/icons-material/Home";
import SearchIcon from "@mui/icons-material/Search";
import AddBoxIcon from "@mui/icons-material/AddBox";
import ChatIcon from "@mui/icons-material/Chat";
import AccountBoxIcon from "@mui/icons-material/AccountBox";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import AutoAwesomeMosaicIcon from "@mui/icons-material/AutoAwesomeMosaic";
import SendIcon from "@mui/icons-material/Send";
// import CameraAltIcon as CameraIcon from '@mui/icons-material/CameraAlt';
import AccountCircleRoundedIcon from "@mui/icons-material/AccountCircleRounded";
import CameraIcon from "@mui/icons-material/CameraAlt";
import AddCircleRoundedIcon from "@mui/icons-material/AddCircleRounded";
import ExploreRoundedIcon from "@mui/icons-material/ExploreRounded";
import ExploreOutlinedIcon from '@mui/icons-material/ExploreOutlined';
import PeopleIcon from '@mui/icons-material/People';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import MessageIcon from '@mui/icons-material/Message';
export {
  HomeIcon,
  SearchIcon,
  AddBoxIcon,
  ChatIcon,
  AccountBoxIcon,
  NotificationsNoneIcon,
  AutoAwesomeMosaicIcon,
  SendIcon,
  CameraIcon,
  AccountCircleRoundedIcon,
  AddCircleRoundedIcon,
  ExploreRoundedIcon,
  ExploreOutlinedIcon,
PeopleIcon,
SettingsIcon,
LogoutIcon,
MessageIcon,

  
};
