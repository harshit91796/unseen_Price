// import { useSelector } from 'react-redux'

// const Loading = () => {

//    const visible= useSelector(state=>state.loading.value)
//   return (
//     <div className="load" style={{display:visible?'initial':'none'}}>
//       <img  src="https://media.tenor.com/RVvnVPK-6dcAAAAM/reload-cat.gif" alt="" />
//     </div>
//   )
// }

// export default Loading
