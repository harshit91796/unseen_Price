

const ErrDefault = () => {
  return (
    <div className="load">
      <img  src="https://i.makeagif.com/media/6-29-2016/yc0uIa.gif" alt="" />
    </div>
  )
}

export default ErrDefault
