
// import { Link } from 'react-router-dom'

// const AskSetup = () => {
//   return (
//     <div className="initial-setup">
//     <h2>Complete Setting Up Your Profile</h2>
//     <p>
//     Completing your profile helps us personalize your experience. Filling relevant fields increases your chances of connecting with others.
//     </p>
//     <span className="gspan" style={{background:'#9500CA',color:'white'}}><Link to='/interst'>Lets do it</Link></span>
//     <span className="gspan" ><Link to='/'>I’ll do it later</Link>
     
//     </span>
    
    
//   </div>
//   )
// }

// export default AskSetup
