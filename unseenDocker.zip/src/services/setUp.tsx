// import { postRequest } from "../utils/service";

// // postRequest(endpoint, data)

// export const getPrefrence = async (data:any) => {
//   return await postRequest("/setup/getprefrence",{"title":data});
// };


// export const updatePrefrence=async(data:any)=>{
//     return await postRequest("/setup/updateprefrence",data);
// }