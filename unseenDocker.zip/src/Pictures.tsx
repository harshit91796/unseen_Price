import product1 from './assets/images/womens/189.jpg';
import product2 from './assets/images/womens/381.jpg';
import product3 from './assets/images/womens/593.jpg';
import product4 from './assets/images/womens/766.jpg';
import product5 from './assets/images/womens/925.jpg';
import product6 from './assets/images/womens/1112.jpg';
import product7 from './assets/images/womens/1257.jpg';
import product8 from './assets/images/womens/1362.jpg';
import product9 from './assets/images/womens/1759.jpg';
import product10 from './assets/images/womens/1933.jpg';

//shopes
import shop1 from './assets/images/shopes/shop1.jpg';
import shop2 from './assets/images/shopes/shop2.jpeg';
import shop3 from './assets/images/shopes/shop3.jpeg';
import shop4 from './assets/images/shopes/shop4.jpeg';
import shop5 from './assets/images/shopes/shop5.jpeg';
import shop6 from './assets/images/shopes/shop6.jpeg';
import shop7 from './assets/images/shopes/shop7.jpeg';
import shop8 from './assets/images/shopes/shop8.jpeg';
import shop9 from './assets/images/shopes/shop9.jpeg';
import shop10 from './assets/images/shopes/shop10.jpeg';
import shop11 from './assets/images/shopes/shop11.jpeg';
import shop12 from './assets/images/shopes/shop12.jpg';

//pansts

import jeans1 from './assets/images/pants/jeans(1).jpg';
import jeans2 from './assets/images/pants/jeans(2).jpg';
import jeans3 from './assets/images/pants/jeans(3).jpg';
import jeans4 from './assets/images/pants/jeans(4).jpg';
import jeans5 from './assets/images/pants/jeans(5).jpg';
import jeans6 from './assets/images/pants/jeans(6).jpg';
import jeans7 from './assets/images/pants/jeans(7).jpg';
import jeans8 from './assets/images/pants/jeans(8).jpg';
import jeans9 from './assets/images/pants/jeans(9).jpg';
import jeans10 from './assets/images/pants/jeans(10).jpg';
import jeans11 from './assets/images/pants/jeans(11).jpg';
import jeans12 from './assets/images/pants/jeans(12).jpg';
import jeans13 from './assets/images/pants/jeans(13).jpg';
import jeans14 from './assets/images/pants/jeans(14).jpg';
import jeans15 from './assets/images/pants/jeans(15).jpg';
import jeans16 from './assets/images/pants/jeans(16).jpg';
import jeans17 from './assets/images/pants/jeans(17).jpg';
import jeans18 from './assets/images/pants/jeans(18).jpg';

//product images

import productImage1 from './assets/images/profile/productImage (1).jpg';
import productImage2 from './assets/images/profile/productImage (2).jpg';
import productImage3 from './assets/images/profile/productImage (3).jpg';
import productImage4 from './assets/images/profile/productImage (4).jpg';
import productImage5 from './assets/images/profile/productImage (5).jpg';

//sneakers

import sneakers1 from './assets/images/sneakers/sneakers (1).jpg';
import sneakers2 from './assets/images/sneakers/sneakers (2).jpg';
import sneakers3 from './assets/images/sneakers/sneakers (3).jpg';
import sneakers4 from './assets/images/sneakers/sneakers (4).jpg';
import sneakers5 from './assets/images/sneakers/sneakers (5).jpg';
import sneakers6 from './assets/images/sneakers/sneakers (6).jpg';
import sneakers7 from './assets/images/sneakers/sneakers (7).jpg';
import sneakers8 from './assets/images/sneakers/sneakers (8).jpg';
import sneakers9 from './assets/images/sneakers/sneakers (9).jpg';
import sneakers10 from './assets/images/sneakers/sneakers (10).jpg';
import sneakers11 from './assets/images/sneakers/sneakers (11).jpg';
import sneakers12 from './assets/images/sneakers/sneakers (12).jpg';
import sneakers13 from './assets/images/sneakers/sneakers (13).jpg';
import sneakers14 from './assets/images/sneakers/sneakers (14).jpg';
import sneakers15 from './assets/images/sneakers/sneakers (15).jpg';
import sneakers16 from './assets/images/sneakers/sneakers (16).jpg';
import sneakers17 from './assets/images/sneakers/sneakers (17).jpg';
import sneakers18 from './assets/images/sneakers/sneakers (18).jpg';
import sneakers19 from './assets/images/sneakers/sneakers (19).jpg';
import sneakers20 from './assets/images/sneakers/sneakers (20).jpg';
import sneakers40 from './assets/images/sneakers/sneakers (40).jpg';

//videos

import video1 from './assets/images/thumbnail1.jpg';
import video2 from './assets/images/thumbnail2.jpg';
import video3 from './assets/images/thumbnail3.jpg';
import video4 from './assets/images/thumbnail4.jpg';





const images = { product1, product2, product3, product4, product5, product6, product7, product8, product9, product10 };

const shopeImages = { shop1, shop2, shop3, shop4, shop5, shop6, shop7, shop8, shop9, shop10, shop11, shop12 };

const pantsImages = { jeans1, jeans2, jeans3, jeans4, jeans5, jeans6, jeans7, jeans8, jeans9, jeans10, jeans11, jeans12, jeans13, jeans14, jeans15, jeans16, jeans17, jeans18 };

const productImages = { productImage1, productImage2, productImage3, productImage4, productImage5 };

const sneakersImages = { sneakers1, sneakers2, sneakers3, sneakers4, sneakers5, sneakers6, sneakers7, sneakers8, sneakers9, sneakers10, sneakers11, sneakers12, sneakers13, sneakers14, sneakers15, sneakers16, sneakers17, sneakers18, sneakers19, sneakers20, sneakers40 };

const videoImages = { video1, video2, video3, video4 };

export { images, shopeImages, pantsImages, productImages, sneakersImages, videoImages};